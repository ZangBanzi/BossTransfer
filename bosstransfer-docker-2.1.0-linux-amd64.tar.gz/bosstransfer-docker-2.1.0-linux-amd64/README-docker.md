﻿# BossTransfer Docker production package

Version: 2.1.0
Architecture: linux/amd64

## Configure

Create the private configuration file, restrict it to its owner, then edit it:

cp .env.example .env
chmod 600 .env

BOSSTRANSFER_MANAGER_HTTP_PORT=18085
BOSSTRANSFER_CLIENT_HTTP_PORT=18086
BOSSTRANSFER_CD2_ADDR=host.docker.internal:19798
BOSSTRANSFER_SETUP_USER=admin
BOSSTRANSFER_SETUP_PASSWORD=password
BOSSTRANSFER_MANAGER_URL=
BOSSTRANSFER_LOCAL_DOWNLOAD_DIR=./data/downloads

The environment Web credentials bootstrap a new data volume only. Later changes do not overwrite credentials changed in the Web UI.

## Start

The package contains its CA bundle and scratch runtime Dockerfiles, so these image builds do not pull a registry base image.

Manager: docker compose -f docker-compose.manager.yml -p bosstransfer-manager build --no-cache; then run docker compose -f docker-compose.manager.yml -p bosstransfer-manager up -d
Client: docker compose -f docker-compose.client.yml -p bosstransfer-client build --no-cache; then run docker compose -f docker-compose.client.yml -p bosstransfer-client up -d
Combined: docker compose -f docker-compose.yml -p bosstransfer build --no-cache; then run docker compose -f docker-compose.yml -p bosstransfer up -d

## First connection

1. Sign in to each new Web service with admin / password and change it in the UI.
2. On the manager, enter the 115 Open AppID, scan the QR code with the owner account, and select the searchable resource directory.
3. Create a customer, set its expiry and device limit, then issue a one-time activation code.
4. On the client, enter the manager URL and code to activate this installation, then bind the customer's own 115 account.
5. Select the local system target. CloudDrive2 and qBittorrent appear as usable choices only after the customer configures and verifies them locally.

## Open in browser

- Manager: http://<NAS-IP>:18085/
- Client: http://<NAS-IP>:18086/

## Verify

docker compose -f docker-compose.client.yml -p bosstransfer-client ps
curl -fsS http://127.0.0.1:18086/api/v1/health/ready

Preserve bosstransfer_manager-data and bosstransfer_client-data across upgrades. Never use docker compose down -v.
